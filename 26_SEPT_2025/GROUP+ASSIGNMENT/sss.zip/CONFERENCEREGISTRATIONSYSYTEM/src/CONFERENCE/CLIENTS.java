package CONFERENCE;

public class CLIENTS {

	public CLIENTS(String role, int userId) {
		// TODO Auto-generated constructor stub
	}

	public CLIENTS(String role, int userId) {
		// TODO Auto-generated constructor stub
	}

}
