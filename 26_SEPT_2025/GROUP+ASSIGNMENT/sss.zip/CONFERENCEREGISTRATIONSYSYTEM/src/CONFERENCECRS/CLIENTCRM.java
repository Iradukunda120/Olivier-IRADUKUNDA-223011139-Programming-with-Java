package CONFERENCE;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import CONFERENCEdb.DB;

import java.awt.event.*;
import java.sql.*;

public class CLIENTCRM extends JPanel implements ActionListener {

    private JTextField idtxt = new JTextField();
    private JTextField nameTxt = new JTextField();
    private JTextField emailTxt = new JTextField();
    private JPasswordField passTxt = new JPasswordField();

    private JButton addBtn = new JButton("Add");
    private JButton updateBtn = new JButton("Update");
    private JButton deleteBtn = new JButton("Delete");
    private JButton loadBtn = new JButton("Load");

    private JTable table;
    private DefaultTableModel model;

    private String currentRole;
    private int currentUserId;

    public CLIENTCRM(String role, int userId) {
        this.currentRole = role;
        this.currentUserId = userId;
        setLayout(null);

        // Table
        String[] columns = {"ClientID", "Name", "Password", "Email"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 220, 700, 250);
        add(sp);

        int y = 20;
        addField("ID", idtxt, y); y += 35;
        addField("Name", nameTxt, y); y += 35;
        addField("Password", passTxt, y); y += 35;
        addField("Email", emailTxt, y); y += 35;

        addButtons();

        if (!role.equalsIgnoreCase("admin")) {
            addBtn.setEnabled(false);
            updateBtn.setEnabled(false);
            deleteBtn.setEnabled(false);
        }

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                    int row = table.getSelectedRow();
                    idtxt.setText(model.getValueAt(row, 0).toString());
                    nameTxt.setText(model.getValueAt(row, 1).toString());
                    passTxt.setText(model.getValueAt(row, 2).toString());
                    emailTxt.setText(model.getValueAt(row, 3).toString());
                }
            }
        });

        loadClients();
    }

    private void addField(String label, JComponent field, int y) {
        JLabel lbl = new JLabel(label + ":");
        lbl.setBounds(20, y, 80, 25);
        field.setBounds(110, y, 150, 25);
        add(lbl);
        add(field);
    }

    private void addButtons() {
        addBtn.setBounds(300, 20, 100, 30);
        updateBtn.setBounds(300, 60, 100, 30);
        deleteBtn.setBounds(300, 100, 100, 30);
        loadBtn.setBounds(300, 140, 100, 30);
        add(addBtn); add(updateBtn); add(deleteBtn); add(loadBtn);
        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);
        loadBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == addBtn) {
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO Clients(Name, PasswordHash, Email) VALUES(?,?,?)");
                ps.setString(1, nameTxt.getText());
                ps.setString(2, new String(passTxt.getPassword()));
                ps.setString(3, emailTxt.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Client Added!");
                loadClients();
            } else if (e.getSource() == updateBtn) {
                if (idtxt.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE Clients SET Name=?, PasswordHash=?, Email=? WHERE ClientID=?");
                ps.setString(1, nameTxt.getText());
                ps.setString(2, new String(passTxt.getPassword()));
                ps.setString(3, emailTxt.getText());
                ps.setInt(4, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Client Updated!");
                loadClients();
            } else if (e.getSource() == deleteBtn) {
                if (idtxt.getText().isEmpty()) return;
                PreparedStatement ps = con.prepareStatement("DELETE FROM Clients WHERE ClientID=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Client Deleted!");
                loadClients();
            } else if (e.getSource() == loadBtn) {
                loadClients();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
        }
    }

    private void loadClients() {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Clients");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("ClientID"),
                        rs.getString("Name"),
                        rs.getString("PasswordHash"),
                        rs.getString("Email")
                });
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
