package CONFERENCECRS;

import javax.swing.*;
import java.awt.*;

// Main CRS JFrame
public class CRS extends JFrame {

    public CRS(String role, int userid) {
        JTabbedPane tabs = new JTabbedPane();
        setTitle("Conference Registration System");
        setSize(900, 600);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the window

        try {
            if (role.equalsIgnoreCase("admin")) {
                tabs.add("Clients", new ClientPanel());          // Manage clients
                tabs.add("Speakers", new SpeakerPanel());        // Manage speakers
                tabs.add("Sessions", new SessionPanel());        // Manage sessions
                tabs.add("Participants", new ParticipantPanel());// Manage participants
                tabs.add("Reports", new ReportPanel());          // View reports
            } 
            else if (role.equalsIgnoreCase("speaker")) {       // Teacher role mapped to speaker
                tabs.add("My Sessions", new SessionPanel());    // View/manage own sessions
                tabs.add("My Participants", new ParticipantPanel()); // View participants in sessions
            } 
            else if (role.equalsIgnoreCase("participant")) {   // Student role mapped to participant
                tabs.add("My Info & Sessions", new ParticipantPanel()); // Personal info and enrolled sessions
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error initializing panel: " + ex.getMessage());
        }

        add(tabs, BorderLayout.CENTER);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // For testing only
    public static void main(String[] args) {
        new CRS("admin", 1);
    }
}

// Dummy panel classes to remove compilation errors
class ClientPanel extends JPanel { public ClientPanel(){ add(new JLabel("Client Panel")); } }
class SpeakerPanel extends JPanel { public SpeakerPanel(){ add(new JLabel("Speaker Panel")); } }
class SessionPanel extends JPanel { public SessionPanel(){ add(new JLabel("Session Panel")); } }
class ParticipantPanel extends JPanel { public ParticipantPanel(){ add(new JLabel("Participant Panel")); } }
class ReportPanel extends JPanel { public ReportPanel(){ add(new JLabel("Report Panel")); } }
